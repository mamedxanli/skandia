The documentation is available online here:
FOR TEMPLATE 1:
http://themes.rokaux.com/unishop/v3.1/template-1/docs/dev-setup.html
FOR TEMPLATE 2:
http://themes.rokaux.com/unishop/v3.1/template-2/docs/dev-setup.html
FOR TEMPLATE 3:
http://themes.rokaux.com/unishop/v3.1/template-3/docs/dev-setup.html
OR
Offline: inside Unishop/dist/docs folder
